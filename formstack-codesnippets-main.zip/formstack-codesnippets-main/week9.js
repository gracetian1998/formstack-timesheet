let weekNineMonday = document.getElementById("field154866614_1");
weekNineMonday.addEventListener("change", calculateWorkingHoursWeekNine);

let weekNineTuesday = document.getElementById("field154866614_2");
weekNineTuesday.addEventListener("change", calculateWorkingHoursWeekNine);

let weekNineWednesday = document.getElementById("field154866614_3");
weekNineWednesday.addEventListener("change", calculateWorkingHoursWeekNine);

let weekNineThursday = document.getElementById("field154866614_4");
weekNineThursday.addEventListener("change", calculateWorkingHoursWeekNine);

let weekNineFriday = document.getElementById("field154866614_5");
weekNineFriday.addEventListener("change", calculateWorkingHoursWeekNine);

let weekNineSaturday = document.getElementById("field154866614_6");
weekNineSaturday.addEventListener("change", calculateWorkingHoursWeekNine);

let weekNineSunday = document.getElementById("field154866614_7");
weekNineSunday.addEventListener("change", calculateWorkingHoursWeekNine);

let weekNineTotalHoursField = document.getElementById("field155564501");

let weekNineMondayLunchBreakField = document.getElementById("field154866618");
weekNineMondayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekNine
);
let weekNineStartHourMonday = document.getElementById("field154866616H");
weekNineStartHourMonday.addEventListener("change", calculateWorkingHoursWeekNine);
let weekNineStartMinuteMonday = document.getElementById("field154866616I");
weekNineStartMinuteMonday.addEventListener(
  "change",
  calculateWorkingHoursWeekNine
);
let weekNineEndHourMonday = document.getElementById("field154866617H");
weekNineEndHourMonday.addEventListener("change", calculateWorkingHoursWeekNine);
let weekNineEndMinuteMonday = document.getElementById("field154866617I");
weekNineEndMinuteMonday.addEventListener("change", calculateWorkingHoursWeekNine);

let weekNineTuesdayLunchBreakField = document.getElementById("field154866622");
weekNineTuesdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekNine
);
let weekNineStartHourTuesday = document.getElementById("field154866620H");
weekNineStartHourTuesday.addEventListener(
  "change",
  calculateWorkingHoursWeekNine
);
let weekNineStartMinuteTuesday = document.getElementById("field154866620I");
weekNineStartMinuteTuesday.addEventListener(
  "change",
  calculateWorkingHoursWeekNine
);
let weekNineEndHourTuesday = document.getElementById("field154866621H");
weekNineEndHourTuesday.addEventListener("change", calculateWorkingHoursWeekNine);
let weekNineEndMinuteTuesday = document.getElementById("field154866621I");
weekNineEndMinuteTuesday.addEventListener(
  "change",
  calculateWorkingHoursWeekNine
);

let weekNineWednesdayLunchBreakField = document.getElementById("field154866626");
weekNineWednesdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekNine
);
let weekNineStartHourWednesday = document.getElementById("field154866624H");
weekNineStartHourWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekNine
);
let weekNineStartMinuteWednesday = document.getElementById("field154866624I");
weekNineStartMinuteWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekNine
);
let weekNineEndHourWednesday = document.getElementById("field154866625H");
weekNineEndHourWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekNine
);
let weekNineEndMinuteWednesday = document.getElementById("field154866625I");
weekNineEndMinuteWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekNine
);

let weekNineThursdayLunchBreakField = document.getElementById("field154866630");
weekNineThursdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekNine
);
let weekNineStartHourThursday = document.getElementById("field154866628H");
weekNineStartHourThursday.addEventListener(
  "change",
  calculateWorkingHoursWeekNine
);
let weekNineStartMinuteThursday = document.getElementById("field154866628I");
weekNineStartMinuteThursday.addEventListener(
  "change",
  calculateWorkingHoursWeekNine
);
let weekNineEndHourThursday = document.getElementById("field154866629H");
weekNineEndHourThursday.addEventListener("change", calculateWorkingHoursWeekNine);
let weekNineEndMinuteThursday = document.getElementById("field154866629I");
weekNineEndMinuteThursday.addEventListener(
  "change",
  calculateWorkingHoursWeekNine
);

let weekNineFridayLunchBreakField = document.getElementById("field154866634");
weekNineFridayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekNine
);
let weekNineStartHourFriday = document.getElementById("field154866632H");
weekNineStartHourFriday.addEventListener("change", calculateWorkingHoursWeekNine);
let weekNineStartMinuteFriday = document.getElementById("field154866632I");
weekNineStartMinuteFriday.addEventListener(
  "change",
  calculateWorkingHoursWeekNine
);
let weekNineEndHourFriday = document.getElementById("field154866633H");
weekNineEndHourFriday.addEventListener("change", calculateWorkingHoursWeekNine);
let weekNineEndMinuteFriday = document.getElementById("field154866633I");
weekNineEndMinuteFriday.addEventListener("change", calculateWorkingHoursWeekNine);

let weekNineSaturdayLunchBreakField = document.getElementById("field154866638");
weekNineSaturdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekNine
);
let weekNineStartHourSaturday = document.getElementById("field154866636H");
weekNineStartHourSaturday.addEventListener(
  "change",
  calculateWorkingHoursWeekNine
);
let weekNineStartMinuteSaturday = document.getElementById("field154866636I");
weekNineStartMinuteSaturday.addEventListener(
  "change",
  calculateWorkingHoursWeekNine
);
let weekNineEndHourSaturday = document.getElementById("field154866637H");
weekNineEndHourSaturday.addEventListener("change", calculateWorkingHoursWeekNine);
let weekNineEndMinuteSaturday = document.getElementById("field154866637I");
weekNineEndMinuteSaturday.addEventListener(
  "change",
  calculateWorkingHoursWeekNine
);

let weekNineSundayLunchBreakField = document.getElementById("field154866642");
weekNineSundayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekNine
);
let weekNineStartHourSunday = document.getElementById("field154866640H");
weekNineStartHourSunday.addEventListener("change", calculateWorkingHoursWeekNine);
let weekNineStartMinuteSunday = document.getElementById("field154866640I");
weekNineStartMinuteSunday.addEventListener(
  "change",
  calculateWorkingHoursWeekNine
);
let weekNineEndHourSunday = document.getElementById("field154866641H");
weekNineEndHourSunday.addEventListener("change", calculateWorkingHoursWeekNine);
let weekNineEndMinuteSunday = document.getElementById("field154866641I");
weekNineEndMinuteSunday.addEventListener("change", calculateWorkingHoursWeekNine);

function calculateWorkingHoursWeekNine() {
  let mondayBreakMinutes = parseInt(weekNineMondayLunchBreakField.value);
  let tuesdayBreakMinutes = parseInt(weekNineTuesdayLunchBreakField.value);
  let wednesdayBreakMinutes = parseInt(weekNineWednesdayLunchBreakField.value);
  let thursdayBreakMinutes = parseInt(weekNineThursdayLunchBreakField.value);
  let fridayBreakMinutes = parseInt(weekNineFridayLunchBreakField.value);
  let saturdayBreakMinutes = parseInt(weekNineSaturdayLunchBreakField.value);
  let sundayBreakMinutes = parseInt(weekNineSundayLunchBreakField.value);

  let mondayMinutes = 0;
  if (weekNineMonday.checked) {
    mondayMinutes = totalHoursWorkedInADay(
      weekNineStartHourMonday,
      weekNineStartMinuteMonday,
      weekNineEndHourMonday,
      weekNineEndMinuteMonday,
      mondayBreakMinutes
    );
  }

  let tuesdayMinutes = 0;
  if (weekNineTuesday.checked) {
    tuesdayMinutes = totalHoursWorkedInADay(
      weekNineStartHourTuesday,
      weekNineStartMinuteTuesday,
      weekNineEndHourTuesday,
      weekNineEndMinuteTuesday,
      tuesdayBreakMinutes
    );
  }
  let wednesdayMinutes = 0;
  if (weekNineWednesday.checked) {
    wednesdayMinutes = totalHoursWorkedInADay(
      weekNineStartHourWednesday,
      weekNineStartMinuteWednesday,
      weekNineEndHourWednesday,
      weekNineEndMinuteWednesday,
      wednesdayBreakMinutes
    );
  }
  let thursdayMinutes = 0;
  if (weekNineThursday.checked) {
    thursdayMinutes = totalHoursWorkedInADay(
      weekNineStartHourThursday,
      weekNineStartMinuteThursday,
      weekNineEndHourThursday,
      weekNineEndMinuteThursday,
      thursdayBreakMinutes
    );
  }

  let fridayMinutes = 0;
  if (weekNineFriday.checked) {
    fridayMinutes = totalHoursWorkedInADay(
      weekNineStartHourFriday,
      weekNineStartMinuteFriday,
      weekNineEndHourFriday,
      weekNineEndMinuteFriday,
      fridayBreakMinutes
    );
  }

  let saturdayMinutes = 0;
  if (weekNineSaturday.checked) {
    saturdayMinutes = totalHoursWorkedInADay(
      weekNineStartHourSaturday,
      weekNineStartMinuteSaturday,
      weekNineEndHourSaturday,
      weekNineEndMinuteSaturday,
      saturdayBreakMinutes
    );
  }

  let sundayMinutes = 0;
  if (weekNineSunday.checked) {
    sundayMinutes = totalHoursWorkedInADay(
      weekNineStartHourSunday,
      weekNineStartMinuteSunday,
      weekNineEndHourSunday,
      weekNineEndMinuteSunday,
      sundayBreakMinutes
    );
  }

  let totalMinutes =
    mondayMinutes +
    tuesdayMinutes +
    wednesdayMinutes +
    thursdayMinutes +
    fridayMinutes +
    saturdayMinutes +
    sundayMinutes;

  if (totalMinutes >= 0) {
    let totalHours = parseFloat(totalMinutes / 60).toFixed(1);
    weekNineTotalHoursField.value = totalHours;
  }
}
