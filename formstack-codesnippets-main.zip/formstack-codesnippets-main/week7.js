let weekSevenMonday = document.getElementById("field154864629_1");
weekSevenMonday.addEventListener("change", calculateWorkingHoursWeekSeven);

let weekSevenTuesday = document.getElementById("field154864629_2");
weekSevenTuesday.addEventListener("change", calculateWorkingHoursWeekSeven);

let weekSevenWednesday = document.getElementById("field154864629_3");
weekSevenWednesday.addEventListener("change", calculateWorkingHoursWeekSeven);

let weekSevenThursday = document.getElementById("field154864629_4");
weekSevenThursday.addEventListener("change", calculateWorkingHoursWeekSeven);

let weekSevenFriday = document.getElementById("field154864629_5");
weekSevenFriday.addEventListener("change", calculateWorkingHoursWeekSeven);

let weekSevenSaturday = document.getElementById("field154864629_6");
weekSevenSaturday.addEventListener("change", calculateWorkingHoursWeekSeven);

let weekSevenSunday = document.getElementById("field154864629_7");
weekSevenSunday.addEventListener("change", calculateWorkingHoursWeekSeven);

let weekSevenTotalHoursField = document.getElementById("field155564418");

let weekSevenMondayLunchBreakField = document.getElementById("field154864633");
weekSevenMondayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekSeven
);
let weekSevenStartHourMonday = document.getElementById("field154864631H");
weekSevenStartHourMonday.addEventListener("change", calculateWorkingHoursWeekSeven);
let weekSevenStartMinuteMonday = document.getElementById("field154864631I");
weekSevenStartMinuteMonday.addEventListener(
  "change",
  calculateWorkingHoursWeekSeven
);
let weekSevenEndHourMonday = document.getElementById("field154864632H");
weekSevenEndHourMonday.addEventListener("change", calculateWorkingHoursWeekSeven);
let weekSevenEndMinuteMonday = document.getElementById("field154864632I");
weekSevenEndMinuteMonday.addEventListener("change", calculateWorkingHoursWeekSeven);

let weekSevenTuesdayLunchBreakField = document.getElementById("field154864637");
weekSevenTuesdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekSeven
);
let weekSevenStartHourTuesday = document.getElementById("field154864635H");
weekSevenStartHourTuesday.addEventListener(
  "change",
  calculateWorkingHoursWeekSeven
);
let weekSevenStartMinuteTuesday = document.getElementById("field154864635I");
weekSevenStartMinuteTuesday.addEventListener(
  "change",
  calculateWorkingHoursWeekSeven
);
let weekSevenEndHourTuesday = document.getElementById("field154864636H");
weekSevenEndHourTuesday.addEventListener("change", calculateWorkingHoursWeekSeven);
let weekSevenEndMinuteTuesday = document.getElementById("field154864636I");
weekSevenEndMinuteTuesday.addEventListener(
  "change",
  calculateWorkingHoursWeekSeven
);

let weekSevenWednesdayLunchBreakField = document.getElementById("field154864641");
weekSevenWednesdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekSeven
);
let weekSevenStartHourWednesday = document.getElementById("field154864639H");
weekSevenStartHourWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekSeven
);
let weekSevenStartMinuteWednesday = document.getElementById("field154864639I");
weekSevenStartMinuteWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekSeven
);
let weekSevenEndHourWednesday = document.getElementById("field154864640H");
weekSevenEndHourWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekSeven
);
let weekSevenEndMinuteWednesday = document.getElementById("field154864640I");
weekSevenEndMinuteWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekSeven
);

let weekSevenThursdayLunchBreakField = document.getElementById("field154864645");
weekSevenThursdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekSeven
);
let weekSevenStartHourThursday = document.getElementById("field154864643H");
weekSevenStartHourThursday.addEventListener(
  "change",
  calculateWorkingHoursWeekSeven
);
let weekSevenStartMinuteThursday = document.getElementById("field154864643I");
weekSevenStartMinuteThursday.addEventListener(
  "change",
  calculateWorkingHoursWeekSeven
);
let weekSevenEndHourThursday = document.getElementById("field154864644H");
weekSevenEndHourThursday.addEventListener("change", calculateWorkingHoursWeekSeven);
let weekSevenEndMinuteThursday = document.getElementById("field154864644I");
weekSevenEndMinuteThursday.addEventListener(
  "change",
  calculateWorkingHoursWeekSeven
);

let weekSevenFridayLunchBreakField = document.getElementById("field154864649");
weekSevenFridayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekSeven
);
let weekSevenStartHourFriday = document.getElementById("field154864647H");
weekSevenStartHourFriday.addEventListener("change", calculateWorkingHoursWeekSeven);
let weekSevenStartMinuteFriday = document.getElementById("field154864647I");
weekSevenStartMinuteFriday.addEventListener(
  "change",
  calculateWorkingHoursWeekSeven
);
let weekSevenEndHourFriday = document.getElementById("field154864648H");
weekSevenEndHourFriday.addEventListener("change", calculateWorkingHoursWeekSeven);
let weekSevenEndMinuteFriday = document.getElementById("field154864648I");
weekSevenEndMinuteFriday.addEventListener("change", calculateWorkingHoursWeekSeven);

let weekSevenSaturdayLunchBreakField = document.getElementById("field154864653");
weekSevenSaturdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekSeven
);
let weekSevenStartHourSaturday = document.getElementById("field154864651H");
weekSevenStartHourSaturday.addEventListener(
  "change",
  calculateWorkingHoursWeekSeven
);
let weekSevenStartMinuteSaturday = document.getElementById("field154864651I");
weekSevenStartMinuteSaturday.addEventListener(
  "change",
  calculateWorkingHoursWeekSeven
);
let weekSevenEndHourSaturday = document.getElementById("field154864652H");
weekSevenEndHourSaturday.addEventListener("change", calculateWorkingHoursWeekSeven);
let weekSevenEndMinuteSaturday = document.getElementById("field154864652I");
weekSevenEndMinuteSaturday.addEventListener(
  "change",
  calculateWorkingHoursWeekSeven
);

let weekSevenSundayLunchBreakField = document.getElementById("field154864657");
weekSevenSundayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekSeven
);
let weekSevenStartHourSunday = document.getElementById("field154864655H");
weekSevenStartHourSunday.addEventListener("change", calculateWorkingHoursWeekSeven);
let weekSevenStartMinuteSunday = document.getElementById("field154864655I");
weekSevenStartMinuteSunday.addEventListener(
  "change",
  calculateWorkingHoursWeekSeven
);
let weekSevenEndHourSunday = document.getElementById("field154864656H");
weekSevenEndHourSunday.addEventListener("change", calculateWorkingHoursWeekSeven);
let weekSevenEndMinuteSunday = document.getElementById("field154864656I");
weekSevenEndMinuteSunday.addEventListener("change", calculateWorkingHoursWeekSeven);

function calculateWorkingHoursWeekSeven() {
  let mondayBreakMinutes = parseInt(weekSevenMondayLunchBreakField.value);
  let tuesdayBreakMinutes = parseInt(weekSevenTuesdayLunchBreakField.value);
  let wednesdayBreakMinutes = parseInt(weekSevenWednesdayLunchBreakField.value);
  let thursdayBreakMinutes = parseInt(weekSevenThursdayLunchBreakField.value);
  let fridayBreakMinutes = parseInt(weekSevenFridayLunchBreakField.value);
  let saturdayBreakMinutes = parseInt(weekSevenSaturdayLunchBreakField.value);
  let sundayBreakMinutes = parseInt(weekSevenSundayLunchBreakField.value);

  let mondayMinutes = 0;
  if (weekSevenMonday.checked) {
    mondayMinutes = totalHoursWorkedInADay(
      weekSevenStartHourMonday,
      weekSevenStartMinuteMonday,
      weekSevenEndHourMonday,
      weekSevenEndMinuteMonday,
      mondayBreakMinutes
    );
  }

  let tuesdayMinutes = 0;
  if (weekSevenTuesday.checked) {
    tuesdayMinutes = totalHoursWorkedInADay(
      weekSevenStartHourTuesday,
      weekSevenStartMinuteTuesday,
      weekSevenEndHourTuesday,
      weekSevenEndMinuteTuesday,
      tuesdayBreakMinutes
    );
  }
  let wednesdayMinutes = 0;
  if (weekSevenWednesday.checked) {
    wednesdayMinutes = totalHoursWorkedInADay(
      weekSevenStartHourWednesday,
      weekSevenStartMinuteWednesday,
      weekSevenEndHourWednesday,
      weekSevenEndMinuteWednesday,
      wednesdayBreakMinutes
    );
  }
  let thursdayMinutes = 0;
  if (weekSevenThursday.checked) {
    thursdayMinutes = totalHoursWorkedInADay(
      weekSevenStartHourThursday,
      weekSevenStartMinuteThursday,
      weekSevenEndHourThursday,
      weekSevenEndMinuteThursday,
      thursdayBreakMinutes
    );
  }

  let fridayMinutes = 0;
  if (weekSevenFriday.checked) {
    fridayMinutes = totalHoursWorkedInADay(
      weekSevenStartHourFriday,
      weekSevenStartMinuteFriday,
      weekSevenEndHourFriday,
      weekSevenEndMinuteFriday,
      fridayBreakMinutes
    );
  }

  let saturdayMinutes = 0;
  if (weekSevenSaturday.checked) {
    saturdayMinutes = totalHoursWorkedInADay(
      weekSevenStartHourSaturday,
      weekSevenStartMinuteSaturday,
      weekSevenEndHourSaturday,
      weekSevenEndMinuteSaturday,
      saturdayBreakMinutes
    );
  }

  let sundayMinutes = 0;
  if (weekSevenSunday.checked) {
    sundayMinutes = totalHoursWorkedInADay(
      weekSevenStartHourSunday,
      weekSevenStartMinuteSunday,
      weekSevenEndHourSunday,
      weekSevenEndMinuteSunday,
      sundayBreakMinutes
    );
  }

  let totalMinutes =
    mondayMinutes +
    tuesdayMinutes +
    wednesdayMinutes +
    thursdayMinutes +
    fridayMinutes +
    saturdayMinutes +
    sundayMinutes;

  if (totalMinutes >= 0) {
    let totalHours = parseFloat(totalMinutes / 60).toFixed(1);
    weekSevenTotalHoursField.value = totalHours;
  }
}
