let weekSixMonday = document.getElementById("field154864272_1");
weekSixMonday.addEventListener("change", calculateWorkingHoursWeekSix);

let weekSixTuesday = document.getElementById("field154864272_2");
weekSixTuesday.addEventListener("change", calculateWorkingHoursWeekSix);

let weekSixWednesday = document.getElementById("field154864272_3");
weekSixWednesday.addEventListener("change", calculateWorkingHoursWeekSix);

let weekSixThursday = document.getElementById("field154864272_4");
weekSixThursday.addEventListener("change", calculateWorkingHoursWeekSix);

let weekSixFriday = document.getElementById("field154864272_5");
weekSixFriday.addEventListener("change", calculateWorkingHoursWeekSix);

let weekSixSaturday = document.getElementById("field154864272_6");
weekSixSaturday.addEventListener("change", calculateWorkingHoursWeekSix);

let weekSixSunday = document.getElementById("field154864272_7");
weekSixSunday.addEventListener("change", calculateWorkingHoursWeekSix);

let weekSixTotalHoursField = document.getElementById("field155564417");

let weekSixMondayLunchBreakField = document.getElementById("field154864276");
weekSixMondayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekSix
);
let weekSixStartHourMonday = document.getElementById("field154864274H");
weekSixStartHourMonday.addEventListener("change", calculateWorkingHoursWeekSix);
let weekSixStartMinuteMonday = document.getElementById("field154864274I");
weekSixStartMinuteMonday.addEventListener(
  "change",
  calculateWorkingHoursWeekSix
);
let weekSixEndHourMonday = document.getElementById("field154864275H");
weekSixEndHourMonday.addEventListener("change", calculateWorkingHoursWeekSix);
let weekSixEndMinuteMonday = document.getElementById("field154864275I");
weekSixEndMinuteMonday.addEventListener("change", calculateWorkingHoursWeekSix);

let weekSixTuesdayLunchBreakField = document.getElementById("field154864280");
weekSixTuesdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekSix
);
let weekSixStartHourTuesday = document.getElementById("field154864278H");
weekSixStartHourTuesday.addEventListener(
  "change",
  calculateWorkingHoursWeekSix
);
let weekSixStartMinuteTuesday = document.getElementById("field154864278I");
weekSixStartMinuteTuesday.addEventListener(
  "change",
  calculateWorkingHoursWeekSix
);
let weekSixEndHourTuesday = document.getElementById("field154864279H");
weekSixEndHourTuesday.addEventListener("change", calculateWorkingHoursWeekSix);
let weekSixEndMinuteTuesday = document.getElementById("field154864279I");
weekSixEndMinuteTuesday.addEventListener(
  "change",
  calculateWorkingHoursWeekSix
);

let weekSixWednesdayLunchBreakField = document.getElementById("field154864284");
weekSixWednesdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekSix
);
let weekSixStartHourWednesday = document.getElementById("field154864282H");
weekSixStartHourWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekSix
);
let weekSixStartMinuteWednesday = document.getElementById("field154864282I");
weekSixStartMinuteWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekSix
);
let weekSixEndHourWednesday = document.getElementById("field154864283H");
weekSixEndHourWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekSix
);
let weekSixEndMinuteWednesday = document.getElementById("field154864283I");
weekSixEndMinuteWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekSix
);

let weekSixThursdayLunchBreakField = document.getElementById("field154864288");
weekSixThursdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekSix
);
let weekSixStartHourThursday = document.getElementById("field154864286H");
weekSixStartHourThursday.addEventListener(
  "change",
  calculateWorkingHoursWeekSix
);
let weekSixStartMinuteThursday = document.getElementById("field154864286I");
weekSixStartMinuteThursday.addEventListener(
  "change",
  calculateWorkingHoursWeekSix
);
let weekSixEndHourThursday = document.getElementById("field154864287H");
weekSixEndHourThursday.addEventListener("change", calculateWorkingHoursWeekSix);
let weekSixEndMinuteThursday = document.getElementById("field154864287I");
weekSixEndMinuteThursday.addEventListener(
  "change",
  calculateWorkingHoursWeekSix
);

let weekSixFridayLunchBreakField = document.getElementById("field154864292");
weekSixFridayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekSix
);
let weekSixStartHourFriday = document.getElementById("field154864290H");
weekSixStartHourFriday.addEventListener("change", calculateWorkingHoursWeekSix);
let weekSixStartMinuteFriday = document.getElementById("field154864290I");
weekSixStartMinuteFriday.addEventListener(
  "change",
  calculateWorkingHoursWeekSix
);
let weekSixEndHourFriday = document.getElementById("field154864291H");
weekSixEndHourFriday.addEventListener("change", calculateWorkingHoursWeekSix);
let weekSixEndMinuteFriday = document.getElementById("field154864291I");
weekSixEndMinuteFriday.addEventListener("change", calculateWorkingHoursWeekSix);

let weekSixSaturdayLunchBreakField = document.getElementById("field154864296");
weekSixSaturdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekSix
);
let weekSixStartHourSaturday = document.getElementById("field154864294H");
weekSixStartHourSaturday.addEventListener(
  "change",
  calculateWorkingHoursWeekSix
);
let weekSixStartMinuteSaturday = document.getElementById("field154864294I");
weekSixStartMinuteSaturday.addEventListener(
  "change",
  calculateWorkingHoursWeekSix
);
let weekSixEndHourSaturday = document.getElementById("field154864295H");
weekSixEndHourSaturday.addEventListener("change", calculateWorkingHoursWeekSix);
let weekSixEndMinuteSaturday = document.getElementById("field154864295I");
weekSixEndMinuteSaturday.addEventListener(
  "change",
  calculateWorkingHoursWeekSix
);

let weekSixSundayLunchBreakField = document.getElementById("field154864300");
weekSixSundayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekSix
);
let weekSixStartHourSunday = document.getElementById("field154864298H");
weekSixStartHourSunday.addEventListener("change", calculateWorkingHoursWeekSix);
let weekSixStartMinuteSunday = document.getElementById("field154864298I");
weekSixStartMinuteSunday.addEventListener(
  "change",
  calculateWorkingHoursWeekSix
);
let weekSixEndHourSunday = document.getElementById("field154864299H");
weekSixEndHourSunday.addEventListener("change", calculateWorkingHoursWeekSix);
let weekSixEndMinuteSunday = document.getElementById("field154864299I");
weekSixEndMinuteSunday.addEventListener("change", calculateWorkingHoursWeekSix);

function calculateWorkingHoursWeekSix() {
  let mondayBreakMinutes = parseInt(weekSixMondayLunchBreakField.value);
  let tuesdayBreakMinutes = parseInt(weekSixTuesdayLunchBreakField.value);
  let wednesdayBreakMinutes = parseInt(weekSixWednesdayLunchBreakField.value);
  let thursdayBreakMinutes = parseInt(weekSixThursdayLunchBreakField.value);
  let fridayBreakMinutes = parseInt(weekSixFridayLunchBreakField.value);
  let saturdayBreakMinutes = parseInt(weekSixSaturdayLunchBreakField.value);
  let sundayBreakMinutes = parseInt(weekSixSundayLunchBreakField.value);

  let mondayMinutes = 0;
  if (weekSixMonday.checked) {
    mondayMinutes = totalHoursWorkedInADay(
      weekSixStartHourMonday,
      weekSixStartMinuteMonday,
      weekSixEndHourMonday,
      weekSixEndMinuteMonday,
      mondayBreakMinutes
    );
  }

  let tuesdayMinutes = 0;
  if (weekSixTuesday.checked) {
    tuesdayMinutes = totalHoursWorkedInADay(
      weekSixStartHourTuesday,
      weekSixStartMinuteTuesday,
      weekSixEndHourTuesday,
      weekSixEndMinuteTuesday,
      tuesdayBreakMinutes
    );
  }
  let wednesdayMinutes = 0;
  if (weekSixWednesday.checked) {
    wednesdayMinutes = totalHoursWorkedInADay(
      weekSixStartHourWednesday,
      weekSixStartMinuteWednesday,
      weekSixEndHourWednesday,
      weekSixEndMinuteWednesday,
      wednesdayBreakMinutes
    );
  }
  let thursdayMinutes = 0;
  if (weekSixThursday.checked) {
    thursdayMinutes = totalHoursWorkedInADay(
      weekSixStartHourThursday,
      weekSixStartMinuteThursday,
      weekSixEndHourThursday,
      weekSixEndMinuteThursday,
      thursdayBreakMinutes
    );
  }

  let fridayMinutes = 0;
  if (weekSixFriday.checked) {
    fridayMinutes = totalHoursWorkedInADay(
      weekSixStartHourFriday,
      weekSixStartMinuteFriday,
      weekSixEndHourFriday,
      weekSixEndMinuteFriday,
      fridayBreakMinutes
    );
  }

  let saturdayMinutes = 0;
  if (weekSixSaturday.checked) {
    saturdayMinutes = totalHoursWorkedInADay(
      weekSixStartHourSaturday,
      weekSixStartMinuteSaturday,
      weekSixEndHourSaturday,
      weekSixEndMinuteSaturday,
      saturdayBreakMinutes
    );
  }

  let sundayMinutes = 0;
  if (weekSixSunday.checked) {
    sundayMinutes = totalHoursWorkedInADay(
      weekSixStartHourSunday,
      weekSixStartMinuteSunday,
      weekSixEndHourSunday,
      weekSixEndMinuteSunday,
      sundayBreakMinutes
    );
  }

  let totalMinutes =
    mondayMinutes +
    tuesdayMinutes +
    wednesdayMinutes +
    thursdayMinutes +
    fridayMinutes +
    saturdayMinutes +
    sundayMinutes;

  if (totalMinutes >= 0) {
    let totalHours = parseFloat(totalMinutes / 60).toFixed(1);
    weekSixTotalHoursField.value = totalHours;
  }
}
