let weekFiveMonday = document.getElementById("field154242576_1");
weekFiveMonday.addEventListener("change", calculateWorkingHoursWeekFive);

let weekFiveTuesday = document.getElementById("field154242576_2");
weekFiveTuesday.addEventListener("change", calculateWorkingHoursWeekFive);

let weekFiveWednesday = document.getElementById("field154242576_3");
weekFiveWednesday.addEventListener("change", calculateWorkingHoursWeekFive);

let weekFiveThursday = document.getElementById("field154242576_4");
weekFiveThursday.addEventListener("change", calculateWorkingHoursWeekFive);

let weekFiveFriday = document.getElementById("field154242576_5");
weekFiveFriday.addEventListener("change", calculateWorkingHoursWeekFive);

let weekFiveSaturday = document.getElementById("field154242576_6");
weekFiveSaturday.addEventListener("change", calculateWorkingHoursWeekFive);

let weekFiveSunday = document.getElementById("field154242576_7");
weekFiveSunday.addEventListener("change", calculateWorkingHoursWeekFive);

let weekFiveTotalHoursField = document.getElementById("field155564400");

let weekFiveMondayLunchBreakField = document.getElementById("field154242580");
weekFiveMondayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekFive
);
let weekFiveStartHourMonday = document.getElementById("field154242578H");
weekFiveStartHourMonday.addEventListener("change", calculateWorkingHoursWeekFive);
let weekFiveStartMinuteMonday = document.getElementById("field154242578I");
weekFiveStartMinuteMonday.addEventListener(
  "change",
  calculateWorkingHoursWeekFive
);
let weekFiveEndHourMonday = document.getElementById("field154242579H");
weekFiveEndHourMonday.addEventListener("change", calculateWorkingHoursWeekFive);
let weekFiveEndMinuteMonday = document.getElementById("field154242579I");
weekFiveEndMinuteMonday.addEventListener("change", calculateWorkingHoursWeekFive);

let weekFiveTuesdayLunchBreakField = document.getElementById("field154242584");
weekFiveTuesdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekFive
);
let weekFiveStartHourTuesday = document.getElementById("field154242582H");
weekFiveStartHourTuesday.addEventListener(
  "change",
  calculateWorkingHoursWeekFive
);
let weekFiveStartMinuteTuesday = document.getElementById("field154242582I");
weekFiveStartMinuteTuesday.addEventListener(
  "change",
  calculateWorkingHoursWeekFive
);
let weekFiveEndHourTuesday = document.getElementById("field154242583H");
weekFiveEndHourTuesday.addEventListener("change", calculateWorkingHoursWeekFive);
let weekFiveEndMinuteTuesday = document.getElementById("field154242583I");
weekFiveEndMinuteTuesday.addEventListener(
  "change",
  calculateWorkingHoursWeekFive
);

let weekFiveWednesdayLunchBreakField = document.getElementById("field154242588");
weekFiveWednesdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekFive
);
let weekFiveStartHourWednesday = document.getElementById("field154242586H");
weekFiveStartHourWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekFive
);
let weekFiveStartMinuteWednesday = document.getElementById("field154242586I");
weekFiveStartMinuteWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekFive
);
let weekFiveEndHourWednesday = document.getElementById("field154242587H");
weekFiveEndHourWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekFive
);
let weekFiveEndMinuteWednesday = document.getElementById("field154242587I");
weekFiveEndMinuteWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekFive
);

let weekFiveThursdayLunchBreakField = document.getElementById("field154242592");
weekFiveThursdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekFive
);
let weekFiveStartHourThursday = document.getElementById("field154242590H");
weekFiveStartHourThursday.addEventListener(
  "change",
  calculateWorkingHoursWeekFive
);
let weekFiveStartMinuteThursday = document.getElementById("field154242590I");
weekFiveStartMinuteThursday.addEventListener(
  "change",
  calculateWorkingHoursWeekFive
);
let weekFiveEndHourThursday = document.getElementById("field154242591H");
weekFiveEndHourThursday.addEventListener("change", calculateWorkingHoursWeekFive);
let weekFiveEndMinuteThursday = document.getElementById("field154242591I");
weekFiveEndMinuteThursday.addEventListener(
  "change",
  calculateWorkingHoursWeekFive
);

let weekFiveFridayLunchBreakField = document.getElementById("field154242596");
weekFiveFridayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekFive
);
let weekFiveStartHourFriday = document.getElementById("field154242594H");
weekFiveStartHourFriday.addEventListener("change", calculateWorkingHoursWeekFive);
let weekFiveStartMinuteFriday = document.getElementById("field154242594I");
weekFiveStartMinuteFriday.addEventListener(
  "change",
  calculateWorkingHoursWeekFive
);
let weekFiveEndHourFriday = document.getElementById("field154242595H");
weekFiveEndHourFriday.addEventListener("change", calculateWorkingHoursWeekFive);
let weekFiveEndMinuteFriday = document.getElementById("field154242595I");
weekFiveEndMinuteFriday.addEventListener("change", calculateWorkingHoursWeekFive);

let weekFiveSaturdayLunchBreakField = document.getElementById("field154242600");
weekFiveSaturdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekFive
);
let weekFiveStartHourSaturday = document.getElementById("field154242598H");
weekFiveStartHourSaturday.addEventListener(
  "change",
  calculateWorkingHoursWeekFive
);
let weekFiveStartMinuteSaturday = document.getElementById("field154242598I");
weekFiveStartMinuteSaturday.addEventListener(
  "change",
  calculateWorkingHoursWeekFive
);
let weekFiveEndHourSaturday = document.getElementById("field154242599H");
weekFiveEndHourSaturday.addEventListener("change", calculateWorkingHoursWeekFive);
let weekFiveEndMinuteSaturday = document.getElementById("field154242599I");
weekFiveEndMinuteSaturday.addEventListener(
  "change",
  calculateWorkingHoursWeekFive
);

let weekFiveSundayLunchBreakField = document.getElementById("field154242604");
weekFiveSundayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekFive
);
let weekFiveStartHourSunday = document.getElementById("field154242602H");
weekFiveStartHourSunday.addEventListener("change", calculateWorkingHoursWeekFive);
let weekFiveStartMinuteSunday = document.getElementById("field154242602I");
weekFiveStartMinuteSunday.addEventListener(
  "change",
  calculateWorkingHoursWeekFive
);
let weekFiveEndHourSunday = document.getElementById("field154242603H");
weekFiveEndHourSunday.addEventListener("change", calculateWorkingHoursWeekFive);
let weekFiveEndMinuteSunday = document.getElementById("field154242603I");
weekFiveEndMinuteSunday.addEventListener("change", calculateWorkingHoursWeekFive);

function calculateWorkingHoursWeekFive() {
  let mondayBreakMinutes = parseInt(weekFiveMondayLunchBreakField.value);
  let tuesdayBreakMinutes = parseInt(weekFiveTuesdayLunchBreakField.value);
  let wednesdayBreakMinutes = parseInt(weekFiveWednesdayLunchBreakField.value);
  let thursdayBreakMinutes = parseInt(weekFiveThursdayLunchBreakField.value);
  let fridayBreakMinutes = parseInt(weekFiveFridayLunchBreakField.value);
  let saturdayBreakMinutes = parseInt(weekFiveSaturdayLunchBreakField.value);
  let sundayBreakMinutes = parseInt(weekFiveSundayLunchBreakField.value);

  let mondayMinutes = 0;
  if (weekFiveMonday.checked) {
    mondayMinutes = totalHoursWorkedInADay(
      weekFiveStartHourMonday,
      weekFiveStartMinuteMonday,
      weekFiveEndHourMonday,
      weekFiveEndMinuteMonday,
      mondayBreakMinutes
    );
  }

  let tuesdayMinutes = 0;
  if (weekFiveTuesday.checked) {
    tuesdayMinutes = totalHoursWorkedInADay(
      weekFiveStartHourTuesday,
      weekFiveStartMinuteTuesday,
      weekFiveEndHourTuesday,
      weekFiveEndMinuteTuesday,
      tuesdayBreakMinutes
    );
  }
  let wednesdayMinutes = 0;
  if (weekFiveWednesday.checked) {
    wednesdayMinutes = totalHoursWorkedInADay(
      weekFiveStartHourWednesday,
      weekFiveStartMinuteWednesday,
      weekFiveEndHourWednesday,
      weekFiveEndMinuteWednesday,
      wednesdayBreakMinutes
    );
  }
  let thursdayMinutes = 0;
  if (weekFiveThursday.checked) {
    thursdayMinutes = totalHoursWorkedInADay(
      weekFiveStartHourThursday,
      weekFiveStartMinuteThursday,
      weekFiveEndHourThursday,
      weekFiveEndMinuteThursday,
      thursdayBreakMinutes
    );
  }

  let fridayMinutes = 0;
  if (weekFiveFriday.checked) {
    fridayMinutes = totalHoursWorkedInADay(
      weekFiveStartHourFriday,
      weekFiveStartMinuteFriday,
      weekFiveEndHourFriday,
      weekFiveEndMinuteFriday,
      fridayBreakMinutes
    );
  }

  let saturdayMinutes = 0;
  if (weekFiveSaturday.checked) {
    saturdayMinutes = totalHoursWorkedInADay(
      weekFiveStartHourSaturday,
      weekFiveStartMinuteSaturday,
      weekFiveEndHourSaturday,
      weekFiveEndMinuteSaturday,
      saturdayBreakMinutes
    );
  }

  let sundayMinutes = 0;
  if (weekFiveSunday.checked) {
    sundayMinutes = totalHoursWorkedInADay(
      weekFiveStartHourSunday,
      weekFiveStartMinuteSunday,
      weekFiveEndHourSunday,
      weekFiveEndMinuteSunday,
      sundayBreakMinutes
    );
  }

  let totalMinutes =
    mondayMinutes +
    tuesdayMinutes +
    wednesdayMinutes +
    thursdayMinutes +
    fridayMinutes +
    saturdayMinutes +
    sundayMinutes;

  if (totalMinutes >= 0) {
    let totalHours = parseFloat(totalMinutes / 60).toFixed(1);
    weekFiveTotalHoursField.value = totalHours;
  }
}
