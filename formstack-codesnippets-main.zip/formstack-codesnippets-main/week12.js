let weekTwelveMonday = document.getElementById("field154867156_1");
weekTwelveMonday.addEventListener("change", calculateWorkingHoursWeekTwelve);

let weekTwelveTuesday = document.getElementById("field154867156_2");
weekTwelveTuesday.addEventListener("change", calculateWorkingHoursWeekTwelve);

let weekTwelveWednesday = document.getElementById("field154867156_3");
weekTwelveWednesday.addEventListener("change", calculateWorkingHoursWeekTwelve);

let weekTwelveThursday = document.getElementById("field154867156_4");
weekTwelveThursday.addEventListener("change", calculateWorkingHoursWeekTwelve);

let weekTwelveFriday = document.getElementById("field154867156_5");
weekTwelveFriday.addEventListener("change", calculateWorkingHoursWeekTwelve);

let weekTwelveSaturday = document.getElementById("field154867156_6");
weekTwelveSaturday.addEventListener("change", calculateWorkingHoursWeekTwelve);

let weekTwelveSunday = document.getElementById("field154867156_7");
weekTwelveSunday.addEventListener("change", calculateWorkingHoursWeekTwelve);

let weekTwelveTotalHoursField = document.getElementById("field155564537");

let weekTwelveMondayLunchBreakField = document.getElementById("field154867160");
weekTwelveMondayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekTwelve
);
let weekTwelveStartHourMonday = document.getElementById("field154867158H");
weekTwelveStartHourMonday.addEventListener("change", calculateWorkingHoursWeekTwelve);
let weekTwelveStartMinuteMonday = document.getElementById("field154867158I");
weekTwelveStartMinuteMonday.addEventListener(
  "change",
  calculateWorkingHoursWeekTwelve
);
let weekTwelveEndHourMonday = document.getElementById("field154867159H");
weekTwelveEndHourMonday.addEventListener("change", calculateWorkingHoursWeekTwelve);
let weekTwelveEndMinuteMonday = document.getElementById("field154867159I");
weekTwelveEndMinuteMonday.addEventListener("change", calculateWorkingHoursWeekTwelve);

let weekTwelveTuesdayLunchBreakField = document.getElementById("field154867164");
weekTwelveTuesdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekTwelve
);
let weekTwelveStartHourTuesday = document.getElementById("field154867162H");
weekTwelveStartHourTuesday.addEventListener(
  "change",
  calculateWorkingHoursWeekTwelve
);
let weekTwelveStartMinuteTuesday = document.getElementById("field154867162I");
weekTwelveStartMinuteTuesday.addEventListener(
  "change",
  calculateWorkingHoursWeekTwelve
);
let weekTwelveEndHourTuesday = document.getElementById("field154867163H");
weekTwelveEndHourTuesday.addEventListener("change", calculateWorkingHoursWeekTwelve);
let weekTwelveEndMinuteTuesday = document.getElementById("field154867163I");
weekTwelveEndMinuteTuesday.addEventListener(
  "change",
  calculateWorkingHoursWeekTwelve
);

let weekTwelveWednesdayLunchBreakField = document.getElementById("field154867168");
weekTwelveWednesdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekTwelve
);
let weekTwelveStartHourWednesday = document.getElementById("field154867166H");
weekTwelveStartHourWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekTwelve
);
let weekTwelveStartMinuteWednesday = document.getElementById("field154867166I");
weekTwelveStartMinuteWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekTwelve
);
let weekTwelveEndHourWednesday = document.getElementById("field154867167H");
weekTwelveEndHourWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekTwelve
);
let weekTwelveEndMinuteWednesday = document.getElementById("field154867167I");
weekTwelveEndMinuteWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekTwelve
);

let weekTwelveThursdayLunchBreakField = document.getElementById("field154867172");
weekTwelveThursdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekTwelve
);
let weekTwelveStartHourThursday = document.getElementById("field154867170H");
weekTwelveStartHourThursday.addEventListener(
  "change",
  calculateWorkingHoursWeekTwelve
);
let weekTwelveStartMinuteThursday = document.getElementById("field154867170I");
weekTwelveStartMinuteThursday.addEventListener(
  "change",
  calculateWorkingHoursWeekTwelve
);
let weekTwelveEndHourThursday = document.getElementById("field154867171H");
weekTwelveEndHourThursday.addEventListener("change", calculateWorkingHoursWeekTwelve);
let weekTwelveEndMinuteThursday = document.getElementById("field154867171I");
weekTwelveEndMinuteThursday.addEventListener(
  "change",
  calculateWorkingHoursWeekTwelve
);

let weekTwelveFridayLunchBreakField = document.getElementById("field154867176");
weekTwelveFridayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekTwelve
);
let weekTwelveStartHourFriday = document.getElementById("field154867174H");
weekTwelveStartHourFriday.addEventListener("change", calculateWorkingHoursWeekTwelve);
let weekTwelveStartMinuteFriday = document.getElementById("field154867174I");
weekTwelveStartMinuteFriday.addEventListener(
  "change",
  calculateWorkingHoursWeekTwelve
);
let weekTwelveEndHourFriday = document.getElementById("field154867175H");
weekTwelveEndHourFriday.addEventListener("change", calculateWorkingHoursWeekTwelve);
let weekTwelveEndMinuteFriday = document.getElementById("field154867175I");
weekTwelveEndMinuteFriday.addEventListener("change", calculateWorkingHoursWeekTwelve);

let weekTwelveSaturdayLunchBreakField = document.getElementById("field154867180");
weekTwelveSaturdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekTwelve
);
let weekTwelveStartHourSaturday = document.getElementById("field154867178H");
weekTwelveStartHourSaturday.addEventListener(
  "change",
  calculateWorkingHoursWeekTwelve
);
let weekTwelveStartMinuteSaturday = document.getElementById("field154867178I");
weekTwelveStartMinuteSaturday.addEventListener(
  "change",
  calculateWorkingHoursWeekTwelve
);
let weekTwelveEndHourSaturday = document.getElementById("field154867179H");
weekTwelveEndHourSaturday.addEventListener("change", calculateWorkingHoursWeekTwelve);
let weekTwelveEndMinuteSaturday = document.getElementById("field154867179I");
weekTwelveEndMinuteSaturday.addEventListener(
  "change",
  calculateWorkingHoursWeekTwelve
);

let weekTwelveSundayLunchBreakField = document.getElementById("field154867184");
weekTwelveSundayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekTwelve
);
let weekTwelveStartHourSunday = document.getElementById("field154867182H");
weekTwelveStartHourSunday.addEventListener("change", calculateWorkingHoursWeekTwelve);
let weekTwelveStartMinuteSunday = document.getElementById("field154867182I");
weekTwelveStartMinuteSunday.addEventListener(
  "change",
  calculateWorkingHoursWeekTwelve
);
let weekTwelveEndHourSunday = document.getElementById("field154867183H");
weekTwelveEndHourSunday.addEventListener("change", calculateWorkingHoursWeekTwelve);
let weekTwelveEndMinuteSunday = document.getElementById("field154867183I");
weekTwelveEndMinuteSunday.addEventListener("change", calculateWorkingHoursWeekTwelve);

function calculateWorkingHoursWeekTwelve() {
  let mondayBreakMinutes = parseInt(weekTwelveMondayLunchBreakField.value);
  let tuesdayBreakMinutes = parseInt(weekTwelveTuesdayLunchBreakField.value);
  let wednesdayBreakMinutes = parseInt(weekTwelveWednesdayLunchBreakField.value);
  let thursdayBreakMinutes = parseInt(weekTwelveThursdayLunchBreakField.value);
  let fridayBreakMinutes = parseInt(weekTwelveFridayLunchBreakField.value);
  let saturdayBreakMinutes = parseInt(weekTwelveSaturdayLunchBreakField.value);
  let sundayBreakMinutes = parseInt(weekTwelveSundayLunchBreakField.value);

  let mondayMinutes = 0;
  if (weekTwelveMonday.checked) {
    mondayMinutes = totalHoursWorkedInADay(
      weekTwelveStartHourMonday,
      weekTwelveStartMinuteMonday,
      weekTwelveEndHourMonday,
      weekTwelveEndMinuteMonday,
      mondayBreakMinutes
    );
  }

  let tuesdayMinutes = 0;
  if (weekTwelveTuesday.checked) {
    tuesdayMinutes = totalHoursWorkedInADay(
      weekTwelveStartHourTuesday,
      weekTwelveStartMinuteTuesday,
      weekTwelveEndHourTuesday,
      weekTwelveEndMinuteTuesday,
      tuesdayBreakMinutes
    );
  }
  let wednesdayMinutes = 0;
  if (weekTwelveWednesday.checked) {
    wednesdayMinutes = totalHoursWorkedInADay(
      weekTwelveStartHourWednesday,
      weekTwelveStartMinuteWednesday,
      weekTwelveEndHourWednesday,
      weekTwelveEndMinuteWednesday,
      wednesdayBreakMinutes
    );
  }
  let thursdayMinutes = 0;
  if (weekTwelveThursday.checked) {
    thursdayMinutes = totalHoursWorkedInADay(
      weekTwelveStartHourThursday,
      weekTwelveStartMinuteThursday,
      weekTwelveEndHourThursday,
      weekTwelveEndMinuteThursday,
      thursdayBreakMinutes
    );
  }

  let fridayMinutes = 0;
  if (weekTwelveFriday.checked) {
    fridayMinutes = totalHoursWorkedInADay(
      weekTwelveStartHourFriday,
      weekTwelveStartMinuteFriday,
      weekTwelveEndHourFriday,
      weekTwelveEndMinuteFriday,
      fridayBreakMinutes
    );
  }

  let saturdayMinutes = 0;
  if (weekTwelveSaturday.checked) {
    saturdayMinutes = totalHoursWorkedInADay(
      weekTwelveStartHourSaturday,
      weekTwelveStartMinuteSaturday,
      weekTwelveEndHourSaturday,
      weekTwelveEndMinuteSaturday,
      saturdayBreakMinutes
    );
  }

  let sundayMinutes = 0;
  if (weekTwelveSunday.checked) {
    sundayMinutes = totalHoursWorkedInADay(
      weekTwelveStartHourSunday,
      weekTwelveStartMinuteSunday,
      weekTwelveEndHourSunday,
      weekTwelveEndMinuteSunday,
      sundayBreakMinutes
    );
  }

  let totalMinutes =
    mondayMinutes +
    tuesdayMinutes +
    wednesdayMinutes +
    thursdayMinutes +
    fridayMinutes +
    saturdayMinutes +
    sundayMinutes;

  if (totalMinutes >= 0) {
    let totalHours = parseFloat(totalMinutes / 60).toFixed(1);
    weekTwelveTotalHoursField.value = totalHours;
  }
}
