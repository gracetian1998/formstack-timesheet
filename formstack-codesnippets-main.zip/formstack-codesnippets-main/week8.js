let weekEightMonday = document.getElementById("field154864724_1");
weekEightMonday.addEventListener("change", calculateWorkingHoursWeekEight);

let weekEightTuesday = document.getElementById("field154864724_2");
weekEightTuesday.addEventListener("change", calculateWorkingHoursWeekEight);

let weekEightWednesday = document.getElementById("field154864724_3");
weekEightWednesday.addEventListener("change", calculateWorkingHoursWeekEight);

let weekEightThursday = document.getElementById("field154864724_4");
weekEightThursday.addEventListener("change", calculateWorkingHoursWeekEight);

let weekEightFriday = document.getElementById("field154864724_5");
weekEightFriday.addEventListener("change", calculateWorkingHoursWeekEight);

let weekEightSaturday = document.getElementById("field154864724_6");
weekEightSaturday.addEventListener("change", calculateWorkingHoursWeekEight);

let weekEightSunday = document.getElementById("field154864724_7");
weekEightSunday.addEventListener("change", calculateWorkingHoursWeekEight);

let weekEightTotalHoursField = document.getElementById("field155564500");

let weekEightMondayLunchBreakField = document.getElementById("field154864728");
weekEightMondayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekEight
);
let weekEightStartHourMonday = document.getElementById("field154864726H");
weekEightStartHourMonday.addEventListener("change", calculateWorkingHoursWeekEight);
let weekEightStartMinuteMonday = document.getElementById("field154864726I");
weekEightStartMinuteMonday.addEventListener(
  "change",
  calculateWorkingHoursWeekEight
);
let weekEightEndHourMonday = document.getElementById("field154864727H");
weekEightEndHourMonday.addEventListener("change", calculateWorkingHoursWeekEight);
let weekEightEndMinuteMonday = document.getElementById("field154864727I");
weekEightEndMinuteMonday.addEventListener("change", calculateWorkingHoursWeekEight);

let weekEightTuesdayLunchBreakField = document.getElementById("field154864732");
weekEightTuesdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekEight
);
let weekEightStartHourTuesday = document.getElementById("field154864730H");
weekEightStartHourTuesday.addEventListener(
  "change",
  calculateWorkingHoursWeekEight
);
let weekEightStartMinuteTuesday = document.getElementById("field154864730I");
weekEightStartMinuteTuesday.addEventListener(
  "change",
  calculateWorkingHoursWeekEight
);
let weekEightEndHourTuesday = document.getElementById("field154864731H");
weekEightEndHourTuesday.addEventListener("change", calculateWorkingHoursWeekEight);
let weekEightEndMinuteTuesday = document.getElementById("field154864731I");
weekEightEndMinuteTuesday.addEventListener(
  "change",
  calculateWorkingHoursWeekEight
);

let weekEightWednesdayLunchBreakField = document.getElementById("field154864736");
weekEightWednesdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekEight
);
let weekEightStartHourWednesday = document.getElementById("field154864734H");
weekEightStartHourWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekEight
);
let weekEightStartMinuteWednesday = document.getElementById("field154864734I");
weekEightStartMinuteWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekEight
);
let weekEightEndHourWednesday = document.getElementById("field154864735H");
weekEightEndHourWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekEight
);
let weekEightEndMinuteWednesday = document.getElementById("field154864735I");
weekEightEndMinuteWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekEight
);

let weekEightThursdayLunchBreakField = document.getElementById("field154864740");
weekEightThursdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekEight
);
let weekEightStartHourThursday = document.getElementById("field154864738H");
weekEightStartHourThursday.addEventListener(
  "change",
  calculateWorkingHoursWeekEight
);
let weekEightStartMinuteThursday = document.getElementById("field154864738I");
weekEightStartMinuteThursday.addEventListener(
  "change",
  calculateWorkingHoursWeekEight
);
let weekEightEndHourThursday = document.getElementById("field154864739H");
weekEightEndHourThursday.addEventListener("change", calculateWorkingHoursWeekEight);
let weekEightEndMinuteThursday = document.getElementById("field154864739I");
weekEightEndMinuteThursday.addEventListener(
  "change",
  calculateWorkingHoursWeekEight
);

let weekEightFridayLunchBreakField = document.getElementById("field154864744");
weekEightFridayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekEight
);
let weekEightStartHourFriday = document.getElementById("field154864742H");
weekEightStartHourFriday.addEventListener("change", calculateWorkingHoursWeekEight);
let weekEightStartMinuteFriday = document.getElementById("field154864742I");
weekEightStartMinuteFriday.addEventListener(
  "change",
  calculateWorkingHoursWeekEight
);
let weekEightEndHourFriday = document.getElementById("field154864743H");
weekEightEndHourFriday.addEventListener("change", calculateWorkingHoursWeekEight);
let weekEightEndMinuteFriday = document.getElementById("field154864743I");
weekEightEndMinuteFriday.addEventListener("change", calculateWorkingHoursWeekEight);

let weekEightSaturdayLunchBreakField = document.getElementById("field154864748");
weekEightSaturdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekEight
);
let weekEightStartHourSaturday = document.getElementById("field154864746H");
weekEightStartHourSaturday.addEventListener(
  "change",
  calculateWorkingHoursWeekEight
);
let weekEightStartMinuteSaturday = document.getElementById("field154864746I");
weekEightStartMinuteSaturday.addEventListener(
  "change",
  calculateWorkingHoursWeekEight
);
let weekEightEndHourSaturday = document.getElementById("field154864747H");
weekEightEndHourSaturday.addEventListener("change", calculateWorkingHoursWeekEight);
let weekEightEndMinuteSaturday = document.getElementById("field154864747I");
weekEightEndMinuteSaturday.addEventListener(
  "change",
  calculateWorkingHoursWeekEight
);

let weekEightSundayLunchBreakField = document.getElementById("field154864752");
weekEightSundayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekEight
);
let weekEightStartHourSunday = document.getElementById("field154864750H");
weekEightStartHourSunday.addEventListener("change", calculateWorkingHoursWeekEight);
let weekEightStartMinuteSunday = document.getElementById("field154864750I");
weekEightStartMinuteSunday.addEventListener(
  "change",
  calculateWorkingHoursWeekEight
);
let weekEightEndHourSunday = document.getElementById("field154864751H");
weekEightEndHourSunday.addEventListener("change", calculateWorkingHoursWeekEight);
let weekEightEndMinuteSunday = document.getElementById("field154864751I");
weekEightEndMinuteSunday.addEventListener("change", calculateWorkingHoursWeekEight);

function calculateWorkingHoursWeekEight() {
  let mondayBreakMinutes = parseInt(weekEightMondayLunchBreakField.value);
  let tuesdayBreakMinutes = parseInt(weekEightTuesdayLunchBreakField.value);
  let wednesdayBreakMinutes = parseInt(weekEightWednesdayLunchBreakField.value);
  let thursdayBreakMinutes = parseInt(weekEightThursdayLunchBreakField.value);
  let fridayBreakMinutes = parseInt(weekEightFridayLunchBreakField.value);
  let saturdayBreakMinutes = parseInt(weekEightSaturdayLunchBreakField.value);
  let sundayBreakMinutes = parseInt(weekEightSundayLunchBreakField.value);

  let mondayMinutes = 0;
  if (weekEightMonday.checked) {
    mondayMinutes = totalHoursWorkedInADay(
      weekEightStartHourMonday,
      weekEightStartMinuteMonday,
      weekEightEndHourMonday,
      weekEightEndMinuteMonday,
      mondayBreakMinutes
    );
  }

  let tuesdayMinutes = 0;
  if (weekEightTuesday.checked) {
    tuesdayMinutes = totalHoursWorkedInADay(
      weekEightStartHourTuesday,
      weekEightStartMinuteTuesday,
      weekEightEndHourTuesday,
      weekEightEndMinuteTuesday,
      tuesdayBreakMinutes
    );
  }
  let wednesdayMinutes = 0;
  if (weekEightWednesday.checked) {
    wednesdayMinutes = totalHoursWorkedInADay(
      weekEightStartHourWednesday,
      weekEightStartMinuteWednesday,
      weekEightEndHourWednesday,
      weekEightEndMinuteWednesday,
      wednesdayBreakMinutes
    );
  }
  let thursdayMinutes = 0;
  if (weekEightThursday.checked) {
    thursdayMinutes = totalHoursWorkedInADay(
      weekEightStartHourThursday,
      weekEightStartMinuteThursday,
      weekEightEndHourThursday,
      weekEightEndMinuteThursday,
      thursdayBreakMinutes
    );
  }

  let fridayMinutes = 0;
  if (weekEightFriday.checked) {
    fridayMinutes = totalHoursWorkedInADay(
      weekEightStartHourFriday,
      weekEightStartMinuteFriday,
      weekEightEndHourFriday,
      weekEightEndMinuteFriday,
      fridayBreakMinutes
    );
  }

  let saturdayMinutes = 0;
  if (weekEightSaturday.checked) {
    saturdayMinutes = totalHoursWorkedInADay(
      weekEightStartHourSaturday,
      weekEightStartMinuteSaturday,
      weekEightEndHourSaturday,
      weekEightEndMinuteSaturday,
      saturdayBreakMinutes
    );
  }

  let sundayMinutes = 0;
  if (weekEightSunday.checked) {
    sundayMinutes = totalHoursWorkedInADay(
      weekEightStartHourSunday,
      weekEightStartMinuteSunday,
      weekEightEndHourSunday,
      weekEightEndMinuteSunday,
      sundayBreakMinutes
    );
  }

  let totalMinutes =
    mondayMinutes +
    tuesdayMinutes +
    wednesdayMinutes +
    thursdayMinutes +
    fridayMinutes +
    saturdayMinutes +
    sundayMinutes;

  if (totalMinutes >= 0) {
    let totalHours = parseFloat(totalMinutes / 60).toFixed(1);
    weekEightTotalHoursField.value = totalHours;
  }
}
