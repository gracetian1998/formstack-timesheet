let weekTenMonday = document.getElementById("field154866799_1");
weekTenMonday.addEventListener("change", calculateWorkingHoursWeekTen);

let weekTenTuesday = document.getElementById("field154866799_2");
weekTenTuesday.addEventListener("change", calculateWorkingHoursWeekTen);

let weekTenWednesday = document.getElementById("field154866799_3");
weekTenWednesday.addEventListener("change", calculateWorkingHoursWeekTen);

let weekTenThursday = document.getElementById("field154866799_4");
weekTenThursday.addEventListener("change", calculateWorkingHoursWeekTen);

let weekTenFriday = document.getElementById("field154866799_5");
weekTenFriday.addEventListener("change", calculateWorkingHoursWeekTen);

let weekTenSaturday = document.getElementById("field154866799_6");
weekTenSaturday.addEventListener("change", calculateWorkingHoursWeekTen);

let weekTenSunday = document.getElementById("field154866799_7");
weekTenSunday.addEventListener("change", calculateWorkingHoursWeekTen);

let weekTenTotalHoursField = document.getElementById("field155564503");

let weekTenMondayLunchBreakField = document.getElementById("field154866803");
weekTenMondayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekTen
);
let weekTenStartHourMonday = document.getElementById("field154866801H");
weekTenStartHourMonday.addEventListener("change", calculateWorkingHoursWeekTen);
let weekTenStartMinuteMonday = document.getElementById("field154866801I");
weekTenStartMinuteMonday.addEventListener(
  "change",
  calculateWorkingHoursWeekTen
);
let weekTenEndHourMonday = document.getElementById("field154866802H");
weekTenEndHourMonday.addEventListener("change", calculateWorkingHoursWeekTen);
let weekTenEndMinuteMonday = document.getElementById("field154866802I");
weekTenEndMinuteMonday.addEventListener("change", calculateWorkingHoursWeekTen);

let weekTenTuesdayLunchBreakField = document.getElementById("field154866807");
weekTenTuesdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekTen
);
let weekTenStartHourTuesday = document.getElementById("field154866805H");
weekTenStartHourTuesday.addEventListener(
  "change",
  calculateWorkingHoursWeekTen
);
let weekTenStartMinuteTuesday = document.getElementById("field154866805I");
weekTenStartMinuteTuesday.addEventListener(
  "change",
  calculateWorkingHoursWeekTen
);
let weekTenEndHourTuesday = document.getElementById("field154866806H");
weekTenEndHourTuesday.addEventListener("change", calculateWorkingHoursWeekTen);
let weekTenEndMinuteTuesday = document.getElementById("field154866806I");
weekTenEndMinuteTuesday.addEventListener(
  "change",
  calculateWorkingHoursWeekTen
);

let weekTenWednesdayLunchBreakField = document.getElementById("field154866811");
weekTenWednesdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekTen
);
let weekTenStartHourWednesday = document.getElementById("field154866809H");
weekTenStartHourWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekTen
);
let weekTenStartMinuteWednesday = document.getElementById("field154866809I");
weekTenStartMinuteWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekTen
);
let weekTenEndHourWednesday = document.getElementById("field154866810H");
weekTenEndHourWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekTen
);
let weekTenEndMinuteWednesday = document.getElementById("field154866810I");
weekTenEndMinuteWednesday.addEventListener(
  "change",
  calculateWorkingHoursWeekTen
);

let weekTenThursdayLunchBreakField = document.getElementById("field154866815");
weekTenThursdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekTen
);
let weekTenStartHourThursday = document.getElementById("field154866813H");
weekTenStartHourThursday.addEventListener(
  "change",
  calculateWorkingHoursWeekTen
);
let weekTenStartMinuteThursday = document.getElementById("field154866813I");
weekTenStartMinuteThursday.addEventListener(
  "change",
  calculateWorkingHoursWeekTen
);
let weekTenEndHourThursday = document.getElementById("field154866814H");
weekTenEndHourThursday.addEventListener("change", calculateWorkingHoursWeekTen);
let weekTenEndMinuteThursday = document.getElementById("field154866814I");
weekTenEndMinuteThursday.addEventListener(
  "change",
  calculateWorkingHoursWeekTen
);

let weekTenFridayLunchBreakField = document.getElementById("field154866819");
weekTenFridayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekTen
);
let weekTenStartHourFriday = document.getElementById("field154866817H");
weekTenStartHourFriday.addEventListener("change", calculateWorkingHoursWeekTen);
let weekTenStartMinuteFriday = document.getElementById("field154866817I");
weekTenStartMinuteFriday.addEventListener(
  "change",
  calculateWorkingHoursWeekTen
);
let weekTenEndHourFriday = document.getElementById("field154866818H");
weekTenEndHourFriday.addEventListener("change", calculateWorkingHoursWeekTen);
let weekTenEndMinuteFriday = document.getElementById("field154866818I");
weekTenEndMinuteFriday.addEventListener("change", calculateWorkingHoursWeekTen);

let weekTenSaturdayLunchBreakField = document.getElementById("field154866823");
weekTenSaturdayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekTen
);
let weekTenStartHourSaturday = document.getElementById("field154866821H");
weekTenStartHourSaturday.addEventListener(
  "change",
  calculateWorkingHoursWeekTen
);
let weekTenStartMinuteSaturday = document.getElementById("field154866821I");
weekTenStartMinuteSaturday.addEventListener(
  "change",
  calculateWorkingHoursWeekTen
);
let weekTenEndHourSaturday = document.getElementById("field154866822H");
weekTenEndHourSaturday.addEventListener("change", calculateWorkingHoursWeekTen);
let weekTenEndMinuteSaturday = document.getElementById("field154866822I");
weekTenEndMinuteSaturday.addEventListener(
  "change",
  calculateWorkingHoursWeekTen
);

let weekTenSundayLunchBreakField = document.getElementById("field154866827");
weekTenSundayLunchBreakField.addEventListener(
  "input",
  calculateWorkingHoursWeekTen
);
let weekTenStartHourSunday = document.getElementById("field154866825H");
weekTenStartHourSunday.addEventListener("change", calculateWorkingHoursWeekTen);
let weekTenStartMinuteSunday = document.getElementById("field154866825I");
weekTenStartMinuteSunday.addEventListener(
  "change",
  calculateWorkingHoursWeekTen
);
let weekTenEndHourSunday = document.getElementById("field154866826H");
weekTenEndHourSunday.addEventListener("change", calculateWorkingHoursWeekTen);
let weekTenEndMinuteSunday = document.getElementById("field154866826I");
weekTenEndMinuteSunday.addEventListener("change", calculateWorkingHoursWeekTen);

function calculateWorkingHoursWeekTen() {
  let mondayBreakMinutes = parseInt(weekTenMondayLunchBreakField.value);
  let tuesdayBreakMinutes = parseInt(weekTenTuesdayLunchBreakField.value);
  let wednesdayBreakMinutes = parseInt(weekTenWednesdayLunchBreakField.value);
  let thursdayBreakMinutes = parseInt(weekTenThursdayLunchBreakField.value);
  let fridayBreakMinutes = parseInt(weekTenFridayLunchBreakField.value);
  let saturdayBreakMinutes = parseInt(weekTenSaturdayLunchBreakField.value);
  let sundayBreakMinutes = parseInt(weekTenSundayLunchBreakField.value);

  let mondayMinutes = 0;
  if (weekTenMonday.checked) {
    mondayMinutes = totalHoursWorkedInADay(
      weekTenStartHourMonday,
      weekTenStartMinuteMonday,
      weekTenEndHourMonday,
      weekTenEndMinuteMonday,
      mondayBreakMinutes
    );
  }

  let tuesdayMinutes = 0;
  if (weekTenTuesday.checked) {
    tuesdayMinutes = totalHoursWorkedInADay(
      weekTenStartHourTuesday,
      weekTenStartMinuteTuesday,
      weekTenEndHourTuesday,
      weekTenEndMinuteTuesday,
      tuesdayBreakMinutes
    );
  }
  let wednesdayMinutes = 0;
  if (weekTenWednesday.checked) {
    wednesdayMinutes = totalHoursWorkedInADay(
      weekTenStartHourWednesday,
      weekTenStartMinuteWednesday,
      weekTenEndHourWednesday,
      weekTenEndMinuteWednesday,
      wednesdayBreakMinutes
    );
  }
  let thursdayMinutes = 0;
  if (weekTenThursday.checked) {
    thursdayMinutes = totalHoursWorkedInADay(
      weekTenStartHourThursday,
      weekTenStartMinuteThursday,
      weekTenEndHourThursday,
      weekTenEndMinuteThursday,
      thursdayBreakMinutes
    );
  }

  let fridayMinutes = 0;
  if (weekTenFriday.checked) {
    fridayMinutes = totalHoursWorkedInADay(
      weekTenStartHourFriday,
      weekTenStartMinuteFriday,
      weekTenEndHourFriday,
      weekTenEndMinuteFriday,
      fridayBreakMinutes
    );
  }

  let saturdayMinutes = 0;
  if (weekTenSaturday.checked) {
    saturdayMinutes = totalHoursWorkedInADay(
      weekTenStartHourSaturday,
      weekTenStartMinuteSaturday,
      weekTenEndHourSaturday,
      weekTenEndMinuteSaturday,
      saturdayBreakMinutes
    );
  }

  let sundayMinutes = 0;
  if (weekTenSunday.checked) {
    sundayMinutes = totalHoursWorkedInADay(
      weekTenStartHourSunday,
      weekTenStartMinuteSunday,
      weekTenEndHourSunday,
      weekTenEndMinuteSunday,
      sundayBreakMinutes
    );
  }

  let totalMinutes =
    mondayMinutes +
    tuesdayMinutes +
    wednesdayMinutes +
    thursdayMinutes +
    fridayMinutes +
    saturdayMinutes +
    sundayMinutes;

  if (totalMinutes >= 0) {
    let totalHours = parseFloat(totalMinutes / 60).toFixed(1);
    weekTenTotalHoursField.value = totalHours;
  }
}
